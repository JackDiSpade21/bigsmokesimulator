/** Automatically generated file. DO NOT MODIFY */
package tk.tgnmc.bigsmokeapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}