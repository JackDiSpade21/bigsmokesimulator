package tk.tgnmc.bigsmokeapp;

import android.app.*;
import android.os.*;
import android.media.*;
import android.widget.*;
import android.view.View.*;
import android.view.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
  
		
		final MediaPlayer oh = MediaPlayer.create(this, R.raw.oh);
		ImageView playoh = (ImageView) this.findViewById(R.id.button2);
		playoh.setOnClickListener(new View.OnClickListener()  {
			
			@Override
			public void onClick(View v) {
				
				oh.start();
			}
			
		});
		
		
		
		
		final MediaPlayer cj = MediaPlayer.create(this, R.raw.cj);
		ImageView playcj = (ImageView) this.findViewById(R.id.button1);
		playcj.setOnClickListener(new View.OnClickListener()  {

				@Override
				public void onClick(View v) {

					cj.start();
				}

			});
		
		
		
		}
	
	
	
	
	
}
